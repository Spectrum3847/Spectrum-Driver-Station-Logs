window.HUFF.registerPage(function(globals) {
   "use strict";

   var SystemAPI = globals.SystemAPI;
   var UIXML = globals.UIXML;
   var CommonUI = globals.CommonUI;

   var onLoad = function() {
      var filter = new SystemAPI.PropertyBag;
      filter.setProperty(SystemAPI.PropertyID.ItemHasService, new SystemAPI.BoolProperty(true));
      filter.setProperty(SystemAPI.PropertyID.ServiceType0, new SystemAPI.UIntProperty(SystemAPI.ServiceType.LocalNetInterface));

      SystemAPI.searchForItemsAndPropertiesFiltered(
         "", SystemAPI.FilterMode.All, filter
      ).then(function (bagResults) {
         return UIXML.getDefinitionsForBag(bagResults.propertyBags);
      }).then(function (bagAndDefs) {
         return CommonUI.generateFromBagAndDefs(bagAndDefs);
      }).then(function (pageContext) {
         return pageContext.updateDelayedProperties();
      });

      return true;
   };

   var onUnload = function() {
      return true;
   };

   return {
      pageName: 'NetworkConfig',
      title: {
         en: "Network Configuration",
      },
      icon: "/HUFF/images/NetworkConfigIcon.png",
      legacyHash: "#/NationalInstruments.Config.NetworkConfig;component/Page.dyn.xaml",
      help: "https://wpilib.screenstepslive.com/s/currentCS/m/getting_started/l/242608-roborio-networking",
      onLoad: onLoad,
      onUnload: onUnload
   };
});
